import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, BookOpen, Users, Star, Play, CheckCircle, Lock, Award, ArrowRight, Menu, X } from 'lucide-react';
import './App.css';

// Komponenten
import CourseModule from './components/CourseModule';
import Quiz from './components/Quiz';
import Progress from './components/Progress';

const App = () => {
  const [currentModule, setCurrentModule] = useState(0);
  const [completedModules, setCompletedModules] = useState([]);
  const [quizScores, setQuizScores] = useState({});
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [userProgress, setUserProgress] = useState({
    totalProgress: 0,
    currentPhase: 'Willkommen',
    timeSpent: 0
  });

  // Kursmodule Daten
  const modules = [
    {
      id: 1,
      title: "Grundlagen des Humanismus in der Erziehung",
      duration: "60-75 Min",
      description: "Entdecken Sie die historischen Wurzeln und philosophischen Grundlagen der humanistischen Pädagogik.",
      videoSrc: "/src/assets/video1_baum_des_wachstums.mp4",
      audioSrc: "/src/assets/audio1_narration.wav",
      content: {
        introduction: "Willkommen zur Revolution der humanistischen Pädagogik...",
        sections: [
          "Die historischen Wurzeln des Humanismus",
          "Das Kind als Subjekt: Ein Paradigmenwechsel", 
          "Shalva Amonashvili: Der Pionier",
          "Die vier Säulen der humanistischen Erziehung"
        ]
      },
      quiz: {
        questions: 10,
        passingScore: 70
      }
    },
    {
      id: 2,
      title: "Die Seele des Kindes verstehen",
      duration: "60-75 Min", 
      description: "Lernen Sie die spirituelle Dimension der humanistischen Erziehung kennen.",
      videoSrc: "/src/assets/video2_kind_als_universum.mp4",
      audioSrc: "/src/assets/audio2_narration.wav",
      content: {
        introduction: "Ein Kind ist kein Projekt. Es ist ein Universum...",
        sections: [
          "Das Kind als geistiges Wesen",
          "Die Höhenwelt: Ursprung und Bestimmung",
          "Die ersten sieben Jahre",
          "Respekt und Würde als Grundlage"
        ]
      },
      quiz: {
        questions: 8,
        passingScore: 70
      }
    },
    {
      id: 3,
      title: "Liebe als höchste Erziehungskraft",
      duration: "60-75 Min",
      description: "Verstehen Sie Liebe als bewusste Entscheidung und transformierende Kraft.",
      videoSrc: "/src/assets/video3_kraft_der_liebe.mp4", 
      audioSrc: "/src/assets/audio3_narration.wav",
      content: {
        introduction: "Liebe ist die höchste Erziehungskraft...",
        sections: [
          "Liebe als Entscheidung",
          "Bedingungslose Annahme",
          "Herz statt Methode",
          "Grenzen mit Liebe"
        ]
      },
      quiz: {
        questions: 8,
        passingScore: 70
      }
    },
    {
      id: 4,
      title: "Die Rolle des Erwachsenen - Selbsterziehung",
      duration: "60-75 Min",
      description: "Erkennen Sie Erziehung als Weg der Selbsterkenntnis und persönlichen Entwicklung.",
      content: {
        introduction: "Der Erwachsene als Spiegel...",
        sections: [
          "Der Erwachsene als Spiegel",
          "Biografiearbeit und Heilung",
          "Vom Formen zum Begleiten",
          "Achtsamkeit im Alltag"
        ]
      },
      quiz: {
        questions: 6,
        passingScore: 70
      }
    },
    {
      id: 5,
      title: "Sprache des Herzens - Heilende Kommunikation",
      duration: "60-75 Min",
      description: "Lernen Sie die Kunst der empathischen, heilenden Kommunikation mit Kindern.",
      content: {
        introduction: "Worte, die heilen...",
        sections: [
          "Die Sprache des Herzens",
          "Gewaltfreie Kommunikation",
          "Aktives Zuhören",
          "Konflikte als Wachstumschancen"
        ]
      },
      quiz: {
        questions: 5,
        passingScore: 70
      }
    },
    {
      id: 6,
      title: "Praktische Umsetzung im Alltag",
      duration: "75-90 Min",
      description: "Integrieren Sie humanistische Prinzipien in den täglichen Umgang mit Kindern.",
      content: {
        introduction: "Der Alltag als heiliger Raum...",
        sections: [
          "Alltag als heiliger Raum",
          "Schöpferische Umgebung",
          "Familie als spirituelle Schule",
          "Krisenmanagement"
        ]
      },
      quiz: {
        questions: 5,
        passingScore: 70
      }
    }
  ];

  // Navigation zwischen Modulen
  const navigateToModule = (moduleIndex) => {
    if (moduleIndex === 0 || completedModules.includes(moduleIndex - 1)) {
      setCurrentModule(moduleIndex);
    }
  };

  // Modul als abgeschlossen markieren
  const completeModule = (moduleIndex, quizScore) => {
    if (!completedModules.includes(moduleIndex)) {
      setCompletedModules([...completedModules, moduleIndex]);
      setQuizScores({...quizScores, [moduleIndex]: quizScore});
      
      // Progress aktualisieren
      const newProgress = ((moduleIndex + 1) / modules.length) * 100;
      setUserProgress(prev => ({
        ...prev,
        totalProgress: newProgress,
        currentPhase: moduleIndex === modules.length - 1 ? 'Abgeschlossen' : modules[moduleIndex + 1].title
      }));
    }
  };

  // Hauptnavigation Komponente
  const Navigation = () => (
    <nav className="bg-white shadow-lg border-b border-amber-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Heart className="h-8 w-8 text-amber-600 mr-3" />
            <h1 className="text-xl font-bold text-gray-900">Humanistische Erziehung</h1>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <div className="flex items-center text-sm text-gray-600">
              <BookOpen className="h-4 w-4 mr-2" />
              {completedModules.length} / {modules.length} Module
            </div>
            <div className="flex items-center text-sm text-gray-600">
              <Star className="h-4 w-4 mr-2" />
              {Math.round(userProgress.totalProgress)}% Fortschritt
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setShowMobileMenu(!showMobileMenu)}
              className="text-gray-600 hover:text-gray-900"
            >
              {showMobileMenu ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      <AnimatePresence>
        {showMobileMenu && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-t border-gray-200"
          >
            <div className="px-4 py-3 space-y-2">
              <div className="flex items-center text-sm text-gray-600">
                <BookOpen className="h-4 w-4 mr-2" />
                {completedModules.length} / {modules.length} Module abgeschlossen
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <Star className="h-4 w-4 mr-2" />
                {Math.round(userProgress.totalProgress)}% Fortschritt
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );

  // Willkommensseite
  const WelcomePage = () => (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-yellow-50">
      <div className="max-w-6xl mx-auto px-4 py-12">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="mb-8">
            <Heart className="h-20 w-20 text-amber-600 mx-auto mb-6" />
            <h1 className="text-5xl font-bold text-gray-900 mb-4">
              Humanistische Erziehung
            </h1>
            <p className="text-xl text-gray-600 mb-2">Grundlehre</p>
            <p className="text-lg text-gray-500 max-w-3xl mx-auto">
              Ein umfassender Online-Kurs basierend auf den Lehren von Shalva Amonashvili 
              und der Philosophie der Humanistischen Schule Schweiz
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white rounded-lg p-6 shadow-lg"
            >
              <BookOpen className="h-12 w-12 text-amber-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">6-8 Stunden Inhalt</h3>
              <p className="text-gray-600">Umfassende Module mit Videos, Übungen und Reflexionen</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-white rounded-lg p-6 shadow-lg"
            >
              <Users className="h-12 w-12 text-amber-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Für Eltern & Pädagogen</h3>
              <p className="text-gray-600">Praktische Anwendung für alle, die mit Kindern arbeiten</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="bg-white rounded-lg p-6 shadow-lg"
            >
              <Award className="h-12 w-12 text-amber-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Zertifikat</h3>
              <p className="text-gray-600">Erhalten Sie ein Zertifikat nach erfolgreichem Abschluss</p>
            </motion.div>
          </div>

          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            onClick={() => window.location.href = '/module/1'}
            className="bg-amber-600 hover:bg-amber-700 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors duration-200 flex items-center mx-auto"
          >
            Kurs beginnen
            <ArrowRight className="ml-2 h-5 w-5" />
          </motion.button>
        </motion.div>

        {/* Kursübersicht */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="bg-white rounded-lg shadow-lg p-8"
        >
          <h2 className="text-3xl font-bold text-center mb-8">Kursmodule</h2>
          <div className="grid gap-6">
            {modules.map((module, index) => (
              <motion.div
                key={module.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1.2 + index * 0.1 }}
                className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center mb-2">
                      <span className="bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-sm font-medium mr-3">
                        Modul {module.id}
                      </span>
                      <span className="text-sm text-gray-500">{module.duration}</span>
                    </div>
                    <h3 className="text-xl font-semibold mb-2">{module.title}</h3>
                    <p className="text-gray-600 mb-4">{module.description}</p>
                    
                    {module.content.sections && (
                      <div className="grid md:grid-cols-2 gap-2">
                        {module.content.sections.map((section, idx) => (
                          <div key={idx} className="flex items-center text-sm text-gray-500">
                            <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                            {section}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  
                  <div className="ml-6 flex flex-col items-center">
                    {completedModules.includes(index) ? (
                      <CheckCircle className="h-8 w-8 text-green-500" />
                    ) : index === 0 || completedModules.includes(index - 1) ? (
                      <Play className="h-8 w-8 text-amber-600" />
                    ) : (
                      <Lock className="h-8 w-8 text-gray-400" />
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        
        <Routes>
          <Route path="/" element={<WelcomePage />} />
          <Route 
            path="/module/:id" 
            element={
              <CourseModule 
                module={modules[currentModule]}
                moduleIndex={currentModule}
                onComplete={completeModule}
                onNext={() => navigateToModule(currentModule + 1)}
                isLocked={currentModule > 0 && !completedModules.includes(currentModule - 1)}
              />
            } 
          />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>

        {/* Progress Indicator */}
        <Progress 
          totalModules={modules.length}
          completedModules={completedModules.length}
          currentModule={currentModule}
          userProgress={userProgress}
        />
      </div>
    </Router>
  );
};

export default App;

