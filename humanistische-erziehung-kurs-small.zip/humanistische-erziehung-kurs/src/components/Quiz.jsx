import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  CheckCircle, 
  XCircle, 
  ArrowRight, 
  ArrowLeft, 
  Award, 
  RefreshCw,
  X,
  Clock,
  Target,
  TrendingUp
} from 'lucide-react';

const Quiz = ({ module, moduleIndex, onComplete, onClose }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [showResults, setShowResults] = useState(false);
  const [score, setScore] = useState(0);
  const [timeSpent, setTimeSpent] = useState(0);
  const [startTime] = useState(Date.now());

  // Beispiel-Quiz-Fragen basierend auf dem Modul
  const getQuizQuestions = (moduleId) => {
    const quizData = {
      1: [
        {
          id: 1,
          type: 'multiple-choice',
          question: 'Was bedeutet der Begriff "Humanitas" ursprünglich?',
          options: [
            'Menschliche Schwäche und Bedürftigkeit',
            'Menschlichkeit, Bildung und Pflege des Menschseins',
            'Wissenschaftliche Erforschung des Menschen',
            'Religiöse Verehrung des Menschen'
          ],
          correct: 1,
          explanation: 'Humanitas stammt aus dem Lateinischen und bedeutet Menschlichkeit, Bildung und die Pflege des Menschseins.'
        },
        {
          id: 2,
          type: 'true-false',
          question: 'In der humanistischen Erziehung wird das Kind als Objekt betrachtet, das geformt werden muss.',
          correct: false,
          explanation: 'Die humanistische Erziehung betrachtet das Kind als Subjekt mit eigener Würde und eigenem Wert.'
        },
        {
          id: 3,
          type: 'multiple-choice',
          question: 'Welche vier Säulen bilden das Fundament der humanistischen Erziehung?',
          options: [
            'Disziplin, Leistung, Anpassung, Gehorsam',
            'Achtsamkeit, Freiheit, Verantwortung, Liebe',
            'Wissen, Können, Wollen, Sollen',
            'Körper, Geist, Seele, Verstand'
          ],
          correct: 1,
          explanation: 'Die vier Säulen der humanistischen Erziehung sind Achtsamkeit, Freiheit, Verantwortung und Liebe.'
        },
        {
          id: 4,
          type: 'scenario',
          question: 'Ein Kind verhält sich "schwierig" und stört den Unterricht. Wie würde ein humanistischer Pädagoge reagieren?',
          options: [
            'Das Kind sofort bestrafen, um ein Beispiel zu setzen',
            'Das Kind ignorieren und weitermachen',
            'Versuchen zu verstehen, welches Bedürfnis sich hinter dem Verhalten ausdrückt',
            'Das Kind vor der Klasse ermahnen'
          ],
          correct: 2,
          explanation: 'In der humanistischen Pädagogik versuchen wir zu verstehen, welche Bedürfnisse sich hinter dem Verhalten ausdrücken.'
        },
        {
          id: 5,
          type: 'multiple-choice',
          question: 'Was unterscheidet die humanistische Sichtweise von der traditionellen Pädagogik?',
          options: [
            'Humanistische Pädagogik ist weniger strukturiert',
            'Sie betrachtet das Kind als vollwertiges Subjekt statt als Objekt',
            'Sie verzichtet völlig auf Regeln und Grenzen',
            'Sie ist nur für begabte Kinder geeignet'
          ],
          correct: 1,
          explanation: 'Der Hauptunterschied liegt darin, dass die humanistische Pädagogik das Kind als vollwertiges Subjekt betrachtet.'
        }
      ],
      2: [
        {
          id: 1,
          type: 'multiple-choice',
          question: 'Wie betrachtet Shalva Amonashvili das Kind in erster Linie?',
          options: [
            'Als biologisches Wesen mit Entwicklungsbedürfnissen',
            'Als psychologisches Phänomen',
            'Als geistiges Wesen und Seele aus der Höhenwelt',
            'Als soziales Produkt seiner Umgebung'
          ],
          correct: 2,
          explanation: 'Amonashvili betrachtet das Kind primär als geistiges Wesen und Seele, die aus der Höhenwelt kommt.'
        },
        {
          id: 2,
          type: 'true-false',
          question: 'Die ersten sieben Lebensjahre haben in der humanistischen Pädagogik eine besondere Bedeutung.',
          correct: true,
          explanation: 'Die ersten sieben Jahre gelten als die prägendsten für die gesamte weitere Entwicklung.'
        },
        {
          id: 3,
          type: 'scenario',
          question: 'Ein fünfjähriges Kind stellt tiefgreifende Fragen über Leben und Tod. Wie sollten Sie reagieren?',
          options: [
            'Das Kind ablenken, da es zu jung für solche Themen ist',
            'Einfache, ehrliche Antworten geben und die Weisheit des Kindes anerkennen',
            'Das Kind an Experten verweisen',
            'Die Fragen ignorieren'
          ],
          correct: 1,
          explanation: 'Kinder haben oft eine intuitive Weisheit und stellen wichtige Fragen, die ernst genommen werden sollten.'
        }
      ],
      3: [
        {
          id: 1,
          type: 'multiple-choice',
          question: 'Wie wird Liebe in der humanistischen Erziehung verstanden?',
          options: [
            'Als Gefühl, das kommt und geht',
            'Als bewusste Entscheidung und Haltung',
            'Als Belohnung für gutes Verhalten',
            'Als natürliche Reaktion auf liebenswerte Kinder'
          ],
          correct: 1,
          explanation: 'Liebe ist in der humanistischen Erziehung eine bewusste Entscheidung und Grundhaltung.'
        },
        {
          id: 2,
          type: 'true-false',
          question: 'Bedingungslose Liebe bedeutet, dass man alles Verhalten des Kindes akzeptieren muss.',
          correct: false,
          explanation: 'Bedingungslose Liebe bedeutet, das Kind als Person anzunehmen, aber nicht jedes Verhalten zu akzeptieren.'
        }
      ]
    };

    return quizData[moduleId] || [];
  };

  const questions = getQuizQuestions(module.id);

  // Timer
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeSpent(Math.floor((Date.now() - startTime) / 1000));
    }, 1000);

    return () => clearInterval(timer);
  }, [startTime]);

  // Antwort auswählen
  const selectAnswer = (questionId, answerIndex) => {
    setAnswers({
      ...answers,
      [questionId]: answerIndex
    });
  };

  // Nächste Frage
  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      calculateResults();
    }
  };

  // Vorherige Frage
  const previousQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  // Ergebnisse berechnen
  const calculateResults = () => {
    let correctAnswers = 0;
    
    questions.forEach(question => {
      const userAnswer = answers[question.id];
      if (question.type === 'true-false') {
        if ((userAnswer === 0 && question.correct === true) || 
            (userAnswer === 1 && question.correct === false)) {
          correctAnswers++;
        }
      } else {
        if (userAnswer === question.correct) {
          correctAnswers++;
        }
      }
    });

    const finalScore = Math.round((correctAnswers / questions.length) * 100);
    setScore(finalScore);
    setShowResults(true);
  };

  // Quiz wiederholen
  const retakeQuiz = () => {
    setCurrentQuestion(0);
    setAnswers({});
    setShowResults(false);
    setScore(0);
  };

  // Zeit formatieren
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const currentQ = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  // Ergebnisseite
  if (showResults) {
    const passed = score >= module.quiz.passingScore;
    
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
        >
          <div className="p-8">
            <div className="text-center mb-8">
              {passed ? (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2 }}
                >
                  <Award className="h-20 w-20 text-green-500 mx-auto mb-4" />
                  <h2 className="text-3xl font-bold text-green-600 mb-2">Herzlichen Glückwunsch!</h2>
                  <p className="text-gray-600">Sie haben das Quiz erfolgreich bestanden!</p>
                </motion.div>
              ) : (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2 }}
                >
                  <XCircle className="h-20 w-20 text-red-500 mx-auto mb-4" />
                  <h2 className="text-3xl font-bold text-red-600 mb-2">Nicht bestanden</h2>
                  <p className="text-gray-600">Sie können das Quiz wiederholen.</p>
                </motion.div>
              )}
            </div>

            {/* Statistiken */}
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <div className="bg-blue-50 rounded-lg p-4 text-center">
                <Target className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-blue-600">{score}%</div>
                <div className="text-sm text-gray-600">Erreichte Punkte</div>
              </div>
              
              <div className="bg-green-50 rounded-lg p-4 text-center">
                <CheckCircle className="h-8 w-8 text-green-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-green-600">
                  {Object.keys(answers).length}/{questions.length}
                </div>
                <div className="text-sm text-gray-600">Fragen beantwortet</div>
              </div>
              
              <div className="bg-purple-50 rounded-lg p-4 text-center">
                <Clock className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-purple-600">{formatTime(timeSpent)}</div>
                <div className="text-sm text-gray-600">Benötigte Zeit</div>
              </div>
            </div>

            {/* Bestehensgrenze */}
            <div className="bg-gray-50 rounded-lg p-4 mb-8">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Bestehensgrenze: {module.quiz.passingScore}%</span>
                <span className="text-sm text-gray-600">Ihr Ergebnis: {score}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div className="relative">
                  <motion.div
                    className={`h-3 rounded-full ${passed ? 'bg-green-500' : 'bg-red-500'}`}
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min(score, 100)}%` }}
                    transition={{ duration: 1, delay: 0.5 }}
                  />
                  <div 
                    className="absolute top-0 w-1 h-3 bg-gray-400"
                    style={{ left: `${module.quiz.passingScore}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Aktionen */}
            <div className="flex flex-col sm:flex-row gap-4">
              {!passed && (
                <button
                  onClick={retakeQuiz}
                  className="flex-1 bg-amber-600 hover:bg-amber-700 text-white py-3 px-6 rounded-lg font-semibold transition-colors flex items-center justify-center"
                >
                  <RefreshCw className="h-5 w-5 mr-2" />
                  Quiz wiederholen
                </button>
              )}
              
              {passed && (
                <button
                  onClick={() => {
                    onComplete(score);
                    onClose();
                  }}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white py-3 px-6 rounded-lg font-semibold transition-colors flex items-center justify-center"
                >
                  <CheckCircle className="h-5 w-5 mr-2" />
                  Modul abschließen
                </button>
              )}
              
              <button
                onClick={onClose}
                className="flex-1 bg-gray-600 hover:bg-gray-700 text-white py-3 px-6 rounded-lg font-semibold transition-colors"
              >
                Schließen
              </button>
            </div>
          </div>
        </motion.div>
      </motion.div>
    );
  }

  // Quiz-Interface
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
      >
        {/* Header */}
        <div className="bg-amber-600 text-white p-6 rounded-t-lg">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold">Quiz - Modul {module.id}</h2>
            <button
              onClick={onClose}
              className="text-white hover:text-gray-200 transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <span>Frage {currentQuestion + 1} von {questions.length}</span>
            <span>Zeit: {formatTime(timeSpent)}</span>
          </div>
          
          {/* Progress Bar */}
          <div className="w-full bg-amber-500 rounded-full h-2 mt-3">
            <motion.div
              className="bg-white h-2 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
        </div>

        {/* Frage */}
        <div className="p-8">
          <motion.div
            key={currentQuestion}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3 }}
          >
            <h3 className="text-xl font-semibold mb-6">{currentQ.question}</h3>

            {/* Multiple Choice / Scenario */}
            {(currentQ.type === 'multiple-choice' || currentQ.type === 'scenario') && (
              <div className="space-y-3">
                {currentQ.options.map((option, index) => (
                  <motion.button
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    onClick={() => selectAnswer(currentQ.id, index)}
                    className={`w-full text-left p-4 rounded-lg border-2 transition-all ${
                      answers[currentQ.id] === index
                        ? 'border-amber-500 bg-amber-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center">
                      <div className={`w-4 h-4 rounded-full border-2 mr-3 ${
                        answers[currentQ.id] === index
                          ? 'border-amber-500 bg-amber-500'
                          : 'border-gray-300'
                      }`}>
                        {answers[currentQ.id] === index && (
                          <div className="w-2 h-2 bg-white rounded-full mx-auto mt-0.5" />
                        )}
                      </div>
                      <span>{option}</span>
                    </div>
                  </motion.button>
                ))}
              </div>
            )}

            {/* True/False */}
            {currentQ.type === 'true-false' && (
              <div className="space-y-3">
                {['Richtig', 'Falsch'].map((option, index) => (
                  <motion.button
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    onClick={() => selectAnswer(currentQ.id, index)}
                    className={`w-full text-left p-4 rounded-lg border-2 transition-all ${
                      answers[currentQ.id] === index
                        ? 'border-amber-500 bg-amber-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center">
                      <div className={`w-4 h-4 rounded-full border-2 mr-3 ${
                        answers[currentQ.id] === index
                          ? 'border-amber-500 bg-amber-500'
                          : 'border-gray-300'
                      }`}>
                        {answers[currentQ.id] === index && (
                          <div className="w-2 h-2 bg-white rounded-full mx-auto mt-0.5" />
                        )}
                      </div>
                      <span>{option}</span>
                    </div>
                  </motion.button>
                ))}
              </div>
            )}
          </motion.div>
        </div>

        {/* Navigation */}
        <div className="bg-gray-50 px-8 py-4 rounded-b-lg flex justify-between">
          <button
            onClick={previousQuestion}
            disabled={currentQuestion === 0}
            className="flex items-center px-4 py-2 text-gray-600 hover:text-gray-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Zurück
          </button>

          <button
            onClick={nextQuestion}
            disabled={answers[currentQ.id] === undefined}
            className="flex items-center px-6 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {currentQuestion === questions.length - 1 ? 'Beenden' : 'Weiter'}
            <ArrowRight className="h-4 w-4 ml-2" />
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default Quiz;

