import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  CheckCircle, 
  ArrowRight, 
  ArrowLeft,
  BookOpen,
  Heart,
  Star,
  Clock,
  Lock
} from 'lucide-react';
import Quiz from './Quiz';

const CourseModule = ({ module, moduleIndex, onComplete, onNext, isLocked }) => {
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [showQuiz, setShowQuiz] = useState(false);
  const [moduleCompleted, setModuleCompleted] = useState(false);
  const [currentSection, setCurrentSection] = useState(0);
  const [readingProgress, setReadingProgress] = useState(0);

  const videoRef = useRef(null);
  const audioRef = useRef(null);
  const contentRef = useRef(null);

  // Scroll-Progress für Lesematerial
  useEffect(() => {
    const handleScroll = () => {
      if (contentRef.current) {
        const element = contentRef.current;
        const scrollTop = element.scrollTop;
        const scrollHeight = element.scrollHeight - element.clientHeight;
        const progress = (scrollTop / scrollHeight) * 100;
        setReadingProgress(Math.min(progress, 100));
      }
    };

    const element = contentRef.current;
    if (element) {
      element.addEventListener('scroll', handleScroll);
      return () => element.removeEventListener('scroll', handleScroll);
    }
  }, []);

  // Video Controls
  const toggleVideo = () => {
    if (videoRef.current) {
      if (isVideoPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsVideoPlaying(!isVideoPlaying);
    }
  };

  // Audio Controls
  const toggleAudio = () => {
    if (audioRef.current) {
      if (isAudioPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsAudioPlaying(!isAudioPlaying);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
    if (audioRef.current) {
      audioRef.current.muted = !isMuted;
    }
  };

  // Quiz abschließen
  const handleQuizComplete = (score) => {
    if (score >= module.quiz.passingScore) {
      setModuleCompleted(true);
      onComplete(moduleIndex, score);
    }
  };

  // Gesperrtes Modul
  if (isLocked) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white rounded-lg shadow-lg p-8 max-w-md text-center"
        >
          <Lock className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Modul gesperrt</h2>
          <p className="text-gray-600 mb-6">
            Bitte schließen Sie das vorherige Modul ab, um dieses Modul freizuschalten.
          </p>
          <button
            onClick={() => window.history.back()}
            className="bg-amber-600 hover:bg-amber-700 text-white px-6 py-2 rounded-lg transition-colors"
          >
            Zurück
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center mb-2">
                <span className="bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-sm font-medium mr-3">
                  Modul {module.id}
                </span>
                <span className="flex items-center text-sm text-gray-500">
                  <Clock className="h-4 w-4 mr-1" />
                  {module.duration}
                </span>
              </div>
              <h1 className="text-3xl font-bold text-gray-900">{module.title}</h1>
              <p className="text-gray-600 mt-2">{module.description}</p>
            </div>
            
            {moduleCompleted && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="flex items-center text-green-600"
              >
                <CheckCircle className="h-8 w-8 mr-2" />
                <span className="font-semibold">Abgeschlossen</span>
              </motion.div>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Hauptinhalt */}
          <div className="lg:col-span-2">
            {/* Video Section */}
            {module.videoSrc && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-lg shadow-lg overflow-hidden mb-8"
              >
                <div className="relative">
                  <video
                    ref={videoRef}
                    className="w-full h-64 object-cover"
                    poster="/api/placeholder/800/400"
                    onPlay={() => setIsVideoPlaying(true)}
                    onPause={() => setIsVideoPlaying(false)}
                  >
                    <source src={module.videoSrc} type="video/mp4" />
                    Ihr Browser unterstützt das Video-Element nicht.
                  </video>
                  
                  {/* Video Controls */}
                  <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                    <button
                      onClick={toggleVideo}
                      className="bg-black bg-opacity-50 hover:bg-opacity-70 text-white p-2 rounded-full transition-all"
                    >
                      {isVideoPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                    </button>
                    
                    <button
                      onClick={toggleMute}
                      className="bg-black bg-opacity-50 hover:bg-opacity-70 text-white p-2 rounded-full transition-all"
                    >
                      {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Audio Section */}
            {module.audioSrc && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="bg-white rounded-lg shadow-lg p-6 mb-8"
              >
                <h3 className="text-xl font-semibold mb-4 flex items-center">
                  <Volume2 className="h-5 w-5 mr-2 text-amber-600" />
                  Audio-Narration
                </h3>
                
                <div className="flex items-center space-x-4">
                  <button
                    onClick={toggleAudio}
                    className="bg-amber-600 hover:bg-amber-700 text-white p-3 rounded-full transition-colors"
                  >
                    {isAudioPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                  </button>
                  
                  <div className="flex-1">
                    <audio
                      ref={audioRef}
                      onPlay={() => setIsAudioPlaying(true)}
                      onPause={() => setIsAudioPlaying(false)}
                      className="w-full"
                      controls
                    >
                      <source src={module.audioSrc} type="audio/wav" />
                      Ihr Browser unterstützt das Audio-Element nicht.
                    </audio>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Textinhalt */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-white rounded-lg shadow-lg p-8 mb-8"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-semibold flex items-center">
                  <BookOpen className="h-6 w-6 mr-2 text-amber-600" />
                  Lerninhalt
                </h3>
                <div className="text-sm text-gray-500">
                  Lesefortschritt: {Math.round(readingProgress)}%
                </div>
              </div>

              <div 
                ref={contentRef}
                className="prose prose-lg max-w-none h-96 overflow-y-auto pr-4"
                style={{ scrollbarWidth: 'thin' }}
              >
                <div className="mb-6">
                  <p className="text-lg text-gray-700 leading-relaxed">
                    {module.content.introduction}
                  </p>
                </div>

                {module.content.sections && (
                  <div className="space-y-6">
                    {module.content.sections.map((section, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.6 + index * 0.1 }}
                        className="border-l-4 border-amber-200 pl-6"
                      >
                        <h4 className="text-xl font-semibold text-gray-900 mb-3">
                          {section}
                        </h4>
                        <p className="text-gray-700 leading-relaxed">
                          Hier würde der detaillierte Inhalt zu diesem Abschnitt stehen. 
                          Jeder Abschnitt enthält tiefgreifende Erkenntnisse und praktische 
                          Anwendungen der humanistischen Erziehungsprinzipien.
                        </p>
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>

              {/* Lesefortschritt */}
              <div className="mt-4">
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <motion.div
                    className="bg-amber-600 h-2 rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: `${readingProgress}%` }}
                    transition={{ duration: 0.3 }}
                  />
                </div>
              </div>
            </motion.div>

            {/* Quiz Button */}
            {!showQuiz && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.8 }}
                className="text-center"
              >
                <button
                  onClick={() => setShowQuiz(true)}
                  className="bg-amber-600 hover:bg-amber-700 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors flex items-center mx-auto"
                >
                  Quiz starten
                  <ArrowRight className="ml-2 h-5 w-5" />
                </button>
              </motion.div>
            )}
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 }}
              className="bg-white rounded-lg shadow-lg p-6 sticky top-8"
            >
              <h3 className="text-xl font-semibold mb-4 flex items-center">
                <Star className="h-5 w-5 mr-2 text-amber-600" />
                Modulübersicht
              </h3>

              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-amber-50 rounded-lg">
                  <span className="text-sm font-medium">Dauer</span>
                  <span className="text-sm text-gray-600">{module.duration}</span>
                </div>

                <div className="flex items-center justify-between p-3 bg-amber-50 rounded-lg">
                  <span className="text-sm font-medium">Quiz-Fragen</span>
                  <span className="text-sm text-gray-600">{module.quiz.questions}</span>
                </div>

                <div className="flex items-center justify-between p-3 bg-amber-50 rounded-lg">
                  <span className="text-sm font-medium">Bestehensgrenze</span>
                  <span className="text-sm text-gray-600">{module.quiz.passingScore}%</span>
                </div>
              </div>

              {module.content.sections && (
                <div className="mt-6">
                  <h4 className="font-semibold mb-3">Inhalte</h4>
                  <div className="space-y-2">
                    {module.content.sections.map((section, index) => (
                      <div
                        key={index}
                        className="flex items-center text-sm text-gray-600 p-2 hover:bg-gray-50 rounded cursor-pointer"
                        onClick={() => setCurrentSection(index)}
                      >
                        <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                        {section}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {moduleCompleted && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg"
                >
                  <div className="flex items-center text-green-800">
                    <CheckCircle className="h-5 w-5 mr-2" />
                    <span className="font-semibold">Modul abgeschlossen!</span>
                  </div>
                  <p className="text-sm text-green-600 mt-1">
                    Sie können nun zum nächsten Modul wechseln.
                  </p>
                  
                  {moduleIndex < 5 && (
                    <button
                      onClick={onNext}
                      className="mt-3 w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg transition-colors"
                    >
                      Nächstes Modul
                    </button>
                  )}
                </motion.div>
              )}
            </motion.div>
          </div>
        </div>
      </div>

      {/* Quiz Modal */}
      <AnimatePresence>
        {showQuiz && (
          <Quiz
            module={module}
            moduleIndex={moduleIndex}
            onComplete={handleQuizComplete}
            onClose={() => setShowQuiz(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default CourseModule;

