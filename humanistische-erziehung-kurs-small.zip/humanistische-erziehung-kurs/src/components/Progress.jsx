import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Circle, Award, TrendingUp } from 'lucide-react';

const Progress = ({ totalModules, completedModules, currentModule, userProgress }) => {
  const progressPercentage = (completedModules / totalModules) * 100;
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed bottom-4 right-4 bg-white rounded-lg shadow-lg border border-gray-200 p-4 max-w-sm z-40"
    >
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-gray-900 flex items-center">
          <TrendingUp className="h-4 w-4 mr-2 text-amber-600" />
          Fortschritt
        </h3>
        <span className="text-sm text-gray-500">
          {Math.round(progressPercentage)}%
        </span>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
        <motion.div
          className="bg-gradient-to-r from-amber-500 to-orange-500 h-2 rounded-full"
          initial={{ width: 0 }}
          animate={{ width: `${progressPercentage}%` }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        />
      </div>

      {/* Module Status */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-600">Module abgeschlossen:</span>
          <span className="font-semibold">{completedModules} / {totalModules}</span>
        </div>
        
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-600">Aktuelle Phase:</span>
          <span className="font-semibold text-amber-600">{userProgress.currentPhase}</span>
        </div>
      </div>

      {/* Module Indicators */}
      <div className="flex items-center justify-center space-x-2 mt-4">
        {Array.from({ length: totalModules }, (_, index) => (
          <motion.div
            key={index}
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: index * 0.1 }}
            className="relative"
          >
            {index < completedModules ? (
              <CheckCircle className="h-6 w-6 text-green-500" />
            ) : index === currentModule ? (
              <Circle className="h-6 w-6 text-amber-500 animate-pulse" />
            ) : (
              <Circle className="h-6 w-6 text-gray-300" />
            )}
            <span className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 text-xs text-gray-500">
              {index + 1}
            </span>
          </motion.div>
        ))}
      </div>

      {/* Completion Badge */}
      {completedModules === totalModules && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg text-center"
        >
          <Award className="h-8 w-8 text-green-600 mx-auto mb-2" />
          <p className="text-sm font-semibold text-green-800">
            Kurs abgeschlossen!
          </p>
          <p className="text-xs text-green-600">
            Herzlichen Glückwunsch zu Ihrem Zertifikat
          </p>
        </motion.div>
      )}
    </motion.div>
  );
};

export default Progress;

